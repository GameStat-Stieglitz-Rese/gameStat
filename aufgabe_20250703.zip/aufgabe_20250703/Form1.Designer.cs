namespace aufgabe_20250703
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            comboBoxSpiele = new System.Windows.Forms.ComboBox();
            lb_ausgabe = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // comboBoxSpiele
            // 
            comboBoxSpiele.FormattingEnabled = true;
            comboBoxSpiele.Location = new System.Drawing.Point(311, 198);
            comboBoxSpiele.Name = "comboBoxSpiele";
            comboBoxSpiele.Size = new System.Drawing.Size(151, 28);
            comboBoxSpiele.TabIndex = 0;
            // 
            // lb_ausgabe
            // 
            lb_ausgabe.AutoSize = true;
            lb_ausgabe.Location = new System.Drawing.Point(142, 105);
            lb_ausgabe.Name = "lb_ausgabe";
            lb_ausgabe.Size = new System.Drawing.Size(489, 20);
            lb_ausgabe.TabIndex = 1;
            lb_ausgabe.Text = "Hier k�nnen Sie die angelegten Spiele im GameStat Datenbank ansehen:";
            lb_ausgabe.Click += label1_Click;
            // 
            // Form1
            // 
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(lb_ausgabe);
            Controls.Add(comboBoxSpiele);
            Name = "Form1";
            Text = "Spielnamen anzeigen";
            ResumeLayout(false);
            PerformLayout();
        }
        private System.Windows.Forms.ComboBox comboBoxSpiele;
        private System.Windows.Forms.Label lb_ausgabe;
    }
}
