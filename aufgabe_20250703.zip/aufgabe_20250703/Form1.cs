using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace aufgabe_20250703
{
    public partial class Form1 : Form
    {
        public Form1() //Maxim Rese, WIV, 03.07.2025
        {
            InitializeComponent();
            LoadSpielnamen();
        }

        private void LoadSpielnamen()
        {
            string connectionString = "server=10.80.0.206;user=team03;password=V6W92;database=team03;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT Spielname FROM spiele";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBoxSpiele.Items.Add(reader.GetString(0));
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Fehler: " + ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
