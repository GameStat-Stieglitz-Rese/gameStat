Mit diesem Programm kann ich die angelegten Spiele im Datenbank anschauen.


Die Installation von MySQL und die Anbindung der des MySQL-Funktions hat gut funktioniert. 
Eigentlich alles, musste wieder reinkommen im c#
Mir ist aufgefallen, um die Datenbank herzustellen, sind die Befehle im Python und C# ähnlich.